//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDR_VERTEX_SHADER_FVF_XYZ_DIFFUSE                     101
#define IDR_PIXEL_SHADER_FVF_XYZ_DIFFUSE                     102
#define IDR_ARIAL_12_SPRITEFONT 103
#define IDR_ARIAL_24_SPRITEFONT 104
#define IDR_ARIAL_36_SPRITEFONT 105
#define IDR_VERTEX_SHADER_SPRITEFONT                     106
#define IDR_PIXEL_SHADER_SPRITEFONT                     107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
