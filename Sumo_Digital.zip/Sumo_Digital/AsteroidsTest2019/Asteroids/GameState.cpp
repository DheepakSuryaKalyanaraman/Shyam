#include "GameState.h"

GameState::GameState()
{
}

GameState::~GameState()
{
}
